import accounts from './accounts';
import courses from './courses';

export default {
    accounts,
    courses
}